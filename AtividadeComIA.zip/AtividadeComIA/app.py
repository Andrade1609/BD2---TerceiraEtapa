import math
import random
import statistics as stats

import altair as alt
import pandas as pd
import streamlit as st

st.set_page_config(page_title="StatQuest", page_icon="🎮", layout="centered")

st.markdown("""
<style>
.chip{display:inline-block;background:#1f2a44;color:#fff;border-radius:12px;
      padding:6px 16px;margin:4px;font-weight:800;font-size:1.4rem}
.stButton>button{border-radius:14px;font-weight:700;padding:.6rem 1rem}
.big{font-size:1.15rem}
</style>
""", unsafe_allow_html=True)

S = st.session_state
for k, v in {"xp": 0, "estrelas": {}, "tela": "mapa", "nivel": None, "quiz": None}.items():
    S.setdefault(k, v)

# ---------------------------------------------------------------- conteúdo
NIVEIS = [
    dict(id="media", nome="Média", emoji="⚖️",
         ideia="Se todo mundo ficasse com a **mesma quantidade**, quanto cada um teria? É a divisão justa!",
         passos=["➕ Some todos os valores", "➗ Divida pela quantidade de valores"],
         exemplo="Valores 4, 6 e 8 → (4 + 6 + 8) ÷ 3 = **6**",
         dica="Um valor muito alto puxa a média para cima."),
    dict(id="mediana", nome="Mediana", emoji="🎯",
         ideia="É o valor que fica **no meio da fila**, depois de colocar tudo em ordem.",
         passos=["📶 Coloque os valores em ordem crescente", "🎯 Pegue o valor do meio",
                 "👯 Se houver dois no meio, tire a média deles"],
         exemplo="Valores 9, 2, 7 → ordem 2, 7, 9 → mediana = **7**",
         dica="Esquecer de ordenar é o erro nº 1!"),
    dict(id="moda", nome="Moda", emoji="🏆",
         ideia="É o valor que **mais aparece**: o campeão de popularidade.",
         passos=["👀 Conte quantas vezes cada valor aparece", "🏆 O que mais se repete é a moda"],
         exemplo="Valores 2, 3, 3, 5, 3 → o 3 aparece 3 vezes → moda = **3**",
         dica="Pode haver duas modas (bimodal) ou nenhuma."),
    dict(id="variancia", nome="Variância", emoji="📏",
         ideia="Mede o quanto os valores **se espalham** em torno da média.",
         passos=["⚖️ Calcule a média", "➖ Subtraia a média de cada valor (desvio)",
                 "²️⃣ Eleve cada desvio ao quadrado", "➗ Calcule a média desses quadrados"],
         exemplo="Valores 2, 4, 6 (média 4) → desvios −2, 0, 2 → quadrados 4, 0, 4 → (4+0+4) ÷ 3 = **2,67**",
         dica="Aqui usamos a variância populacional: dividimos por n."),
    dict(id="dp", nome="Desvio padrão", emoji="🔥",
         ideia="É a **raiz quadrada da variância**. Ele volta para a mesma unidade dos dados.",
         passos=["📏 Calcule a variância", "√ Tire a raiz quadrada"],
         exemplo="Variância 9 → desvio padrão = √9 = **3**",
         dica="Desvio pequeno = valores juntinhos. Desvio grande = valores espalhados."),
    dict(id="chefao", nome="Chefão final", emoji="👑"),
]

TEMAS = ["Você fez estas pontuações em {n} partidas:",
         "Estas foram as moedas coletadas em {n} fases:",
         "Seu time marcou estes gols em {n} jogos:"]

CONC = {
    "media": [("Se **todos** os valores aumentarem 5 unidades, o que acontece com a média?",
               "Aumenta 5", ["Não muda", "Dobra", "Diminui 5"],
               "Todos sobem 5, então a média também sobe 5.")],
    "mediana": [("Em {2, 3, 4, 100}, qual medida sofre **menos** com o valor extremo 100?",
                 "A mediana", ["A média", "A soma", "Nenhuma"],
                 "A mediana olha só para o meio; a média é puxada pelo 100.")],
    "moda": [("O conjunto {2, 3, 3, 5, 5, 7} é...",
              "Bimodal (modas 3 e 5)", ["Unimodal (moda 3)", "Sem moda", "Moda 4"],
              "3 e 5 aparecem 2 vezes cada, então há duas modas.")],
    "variancia": [("A variância pode ser negativa?",
                   "Não: é média de quadrados, sempre ≥ 0",
                   ["Sim, se houver valores abaixo da média", "Sim, se a média for negativa",
                    "Só com número ímpar de dados"],
                   "Quadrados nunca são negativos, então a variância é sempre ≥ 0.")],
    "dp": [("Dois times têm média 10 pontos. Time A: desvio 1. Time B: desvio 5. Quem é mais regular?",
            "Time A", ["Time B", "Iguais", "Não dá para saber"],
            "Menor desvio padrão = resultados mais próximos da média."),
           ("Se o desvio padrão é **0**, o que isso significa?",
            "Todos os valores são iguais", ["A média é zero", "Há um valor zero", "Não há moda"],
            "Sem espalhamento algum: todos os valores coincidem com a média.")],
}

# ---------------------------------------------------------------- geradores
def fmt(x):
    return f"{x:.2f}".rstrip("0").rstrip(".").replace(".", ",")


def opcoes_num(correta, falsas):
    c, ops = fmt(correta), []
    for f in falsas:
        s = fmt(f)
        if f >= 0 and s != c and s not in ops:
            ops.append(s)
    k = 1
    while len(ops) < 3:
        for cand in (correta + k, correta - k):
            s = fmt(cand)
            if cand >= 0 and s != c and s not in ops and len(ops) < 3:
                ops.append(s)
        k += 1
    ops = random.sample(ops, 3) + [c]
    random.shuffle(ops)
    return ops, c


def dados_media_inteira(n, lo, hi):
    v = [random.randint(lo, hi) for _ in range(n)]
    v[-1] += (-sum(v)) % n
    return v


def tabela(v, m):
    t = ["| Valor | Desvio (x − média) | Desvio² |", "|:-:|:-:|:-:|"]
    for x in v:
        t.append(f"| {x} | {fmt(x - m)} | {fmt((x - m) ** 2)} |")
    return "\n".join(t)


def q_media():
    v = dados_media_inteira(random.choice([4, 5, 6]), 3, 15)
    m = sum(v) / len(v)
    ops, c = opcoes_num(m, [m + 1, m - 1, stats.median(v), sum(v)])
    return dict(txt=random.choice(TEMAS).format(n=len(v)) + "\n\nQual é a **média**?", dados=v, ops=ops, ok=c,
                expl=f"Soma: {' + '.join(map(str, v))} = **{sum(v)}**. Dividindo por {len(v)}: **{fmt(m)}**.")


def q_mediana():
    n = random.choice([5, 6, 7])
    v = random.sample(range(1, 25), n)
    s = sorted(v)
    while v == s:
        random.shuffle(v)
    med = stats.median(s)
    if n % 2:
        expl = f"Em ordem: {', '.join(map(str, s))}. O valor do meio é **{fmt(med)}**."
    else:
        a, b = s[n // 2 - 1], s[n // 2]
        expl = (f"Em ordem: {', '.join(map(str, s))}. Os dois do meio são {a} e {b}: "
                f"({a} + {b}) ÷ 2 = **{fmt(med)}**.")
    ops, c = opcoes_num(med, [v[n // 2], sum(v) / n, s[n // 2], s[n // 2 - 1]])
    return dict(txt="Qual é a **mediana**? (cuidado: a lista não está em ordem!)", dados=v, ops=ops, ok=c, expl=expl)


def q_moda():
    moda = random.randint(1, 9)
    outros = random.sample([x for x in range(1, 13) if x != moda], 4)
    v = [moda] * 3 + outros + [random.choice(outros)]
    random.shuffle(v)
    ops, c = opcoes_num(moda, outros + [round(sum(v) / len(v))])
    return dict(txt="Qual é a **moda**?", dados=v, ops=ops, ok=c,
                expl=f"O número **{moda}** aparece 3 vezes, mais que qualquer outro.")


def q_variancia():
    while True:
        n = random.choice([4, 5])
        v = dados_media_inteira(n, 2, 14)
        m = sum(v) // n
        sq = sum((x - m) ** 2 for x in v)
        if sq > 0:
            break
    var = sq / n
    ops, c = opcoes_num(var, [sq, math.sqrt(var), sq / (n - 1), sum(abs(x - m) for x in v) / n])
    return dict(txt="Calcule a **variância** (divida por n).\n\nDica: a média é " + str(m) + ".",
                dados=v, ops=ops, ok=c,
                expl=f"Média = {m}.\n\n{tabela(v, m)}\n\nSoma dos quadrados = {sq}. Variância = {sq} ÷ {n} = **{fmt(var)}**.")


def q_dp():
    for _ in range(3000):
        n = random.choice([4, 5])
        v = dados_media_inteira(n, 1, 15)
        m = sum(v) // n
        sq = sum((x - m) ** 2 for x in v)
        if sq > 0 and sq % n == 0 and math.isqrt(sq // n) ** 2 == sq // n:
            break
    var = sq / n
    dp = math.sqrt(var)
    ops, c = opcoes_num(dp, [var, dp + 1, dp - 1, dp * 2])
    return dict(txt="Calcule o **desvio padrão**.\n\nDica: a média é " + str(m) + ".", dados=v, ops=ops, ok=c,
                expl=f"Média = {m}.\n\n{tabela(v, m)}\n\nVariância = {sq} ÷ {n} = {fmt(var)}. "
                     f"Desvio padrão = √{fmt(var)} = **{fmt(dp)}**.")


def conc(nid):
    t, c, f, e = random.choice(CONC[nid])
    ops = f + [c]
    random.shuffle(ops)
    return dict(txt=t, dados=None, ops=ops, ok=c, expl=e)


GER = dict(media=q_media, mediana=q_mediana, moda=q_moda, variancia=q_variancia, dp=q_dp)


def novo_quiz(i):
    nid = NIVEIS[i]["id"]
    if nid == "chefao":
        qs = [g() for g in GER.values()]
        random.shuffle(qs)
        qs.append(conc(random.choice(list(CONC))))
    else:
        qs = [GER[nid]() for _ in range(4)] + [conc(nid)]
    return dict(nivel=i, qs=qs, idx=0, vidas=3, resp=None, acertos=0, fim=False)

# ---------------------------------------------------------------- ações
def ir(tela, nivel=None):
    S.tela, S.nivel = tela, nivel


def jogar(i):
    S.quiz = novo_quiz(i)
    ir("quiz", i)


def responder(op):
    q = S.quiz
    q["resp"] = op
    if op == q["qs"][q["idx"]]["ok"]:
        q["acertos"] += 1
        S.xp += 10
    else:
        q["vidas"] -= 1


def proxima():
    S.quiz["idx"] += 1
    S.quiz["resp"] = None


def liberado(i):
    return i == 0 or (i - 1) in S.estrelas


def estrelas_txt(n):
    return "⭐" * n + "☆" * (3 - n)

# ---------------------------------------------------------------- telas
def tela_mapa():
    st.subheader("🗺️ Sua trilha")
    for i, n in enumerate(NIVEIS):
        with st.container(border=True):
            c1, c2, c3 = st.columns([1, 4, 3])
            c1.markdown(f"## {n['emoji']}")
            c2.markdown(f"**Fase {i + 1}: {n['nome']}**  \n{estrelas_txt(S.estrelas.get(i, 0))}")
            if not liberado(i):
                c3.button("🔒 Bloqueada", disabled=True, key=f"b{i}", use_container_width=True)
            elif n["id"] == "chefao":
                c3.button("⚔️ Enfrentar", key=f"b{i}", on_click=jogar, args=(i,), use_container_width=True)
            else:
                c3.button("▶️ Jogar", key=f"b{i}", on_click=ir, args=("licao", i), use_container_width=True)


def tela_licao():
    i = S.nivel
    n = NIVEIS[i]
    st.header(f"{n['emoji']} {n['nome']}")
    st.markdown(f"<div class='big'>{n['ideia']}</div>", unsafe_allow_html=True)
    st.markdown("**Como fazer:**")
    for p in n["passos"]:
        st.markdown(f"- {p}")
    st.info(f"**Exemplo:** {n['exemplo']}")
    st.caption(f"💡 {n['dica']}")
    c1, c2 = st.columns(2)
    c1.button("⬅️ Voltar", on_click=ir, args=("mapa",), use_container_width=True)
    c2.button("🎮 Começar desafio", type="primary", on_click=jogar, args=(i,), use_container_width=True)


def tela_resultado(q):
    i = q["nivel"]
    if q["vidas"] > 0:
        if not q["fim"]:
            q["fim"] = True
            if q["vidas"] == 3:
                S.xp += 20
                st.balloons()
            S.estrelas[i] = max(S.estrelas.get(i, 0), q["vidas"])
        st.success(f"### 🎉 Fase concluída!\n{estrelas_txt(q['vidas'])}")
        st.write(f"Acertos: **{q['acertos']}/{len(q['qs'])}**" + ("  ·  Bônus perfeito: **+20 XP** 🌟" if q["vidas"] == 3 else ""))
        c1, c2 = st.columns(2)
        c1.button("🔁 Jogar de novo", on_click=jogar, args=(i,), use_container_width=True)
        c2.button("🗺️ Voltar à trilha", type="primary", on_click=ir, args=("mapa",), use_container_width=True)
    else:
        st.error("### 💔 Suas vidas acabaram!\nSem problema: errar faz parte de aprender.")
        c1, c2 = st.columns(2)
        c1.button("📖 Rever a lição", on_click=ir, args=("licao" if NIVEIS[i]["id"] != "chefao" else "mapa", i),
                  use_container_width=True)
        c2.button("🔁 Tentar de novo", type="primary", on_click=jogar, args=(i,), use_container_width=True)


def tela_quiz():
    q = S.quiz
    if q["vidas"] <= 0 or q["idx"] >= len(q["qs"]):
        return tela_resultado(q)
    p = q["qs"][q["idx"]]
    st.progress(q["idx"] / len(q["qs"]))
    st.markdown(f"**{NIVEIS[q['nivel']]['emoji']} {NIVEIS[q['nivel']]['nome']}**  ·  "
                f"{'❤️' * q['vidas']}{'🖤' * (3 - q['vidas'])}")
    st.markdown(f"<div class='big'>{p['txt']}</div>", unsafe_allow_html=True)
    if p["dados"]:
        st.markdown("".join(f"<span class='chip'>{x}</span>" for x in p["dados"]), unsafe_allow_html=True)
    st.write("")
    cols = st.columns(2)
    for k, op in enumerate(p["ops"]):
        rot = op
        if q["resp"] is not None:
            rot = ("✅ " if op == p["ok"] else "❌ " if op == q["resp"] else "") + op
        cols[k % 2].button(rot, key=f"o{q['idx']}_{k}", disabled=q["resp"] is not None,
                           on_click=responder, args=(op,), use_container_width=True)
    if q["resp"] is not None:
        if q["resp"] == p["ok"]:
            st.success("🎯 Acertou! **+10 XP**")
        else:
            st.error("Quase! Veja como resolver:")
        st.markdown(p["expl"])
        st.button("Continuar ➡️", type="primary", on_click=proxima, use_container_width=True)


def tela_lab():
    st.subheader("🧪 Laboratório")
    st.caption("Mexa nos valores e veja as medidas mudarem em tempo real!")
    padrao = [4, 6, 6, 8, 10, 16]
    cols = st.columns(len(padrao))
    v = [c.slider(f"V{k + 1}", 0, 20, padrao[k], key=f"lab{k}") for k, c in enumerate(cols)]
    media, med = stats.mean(v), stats.median(v)
    var, dp = stats.pvariance(v), stats.pstdev(v)
    modas = stats.multimode(v)
    moda = "sem moda" if len(modas) == len(set(v)) and len(set(v)) > 1 else ", ".join(map(str, sorted(modas)))
    m = st.columns(5)
    for c, (t, val) in zip(m, [("Média", fmt(media)), ("Mediana", fmt(med)), ("Moda", moda),
                               ("Variância", fmt(var)), ("Desv. padrão", fmt(dp))]):
        c.metric(t, val)
    df = pd.DataFrame({"Jogador": range(1, len(v) + 1), "Valor": v})
    banda = pd.DataFrame({"a": [media - dp], "b": [media + dp]})
    base = alt.Chart(df).mark_circle(size=250).encode(x=alt.X("Jogador:O", axis=alt.Axis(labelAngle=0)),
                                                      y=alt.Y("Valor:Q", scale=alt.Scale(domain=[0, 20])))
    faixa = alt.Chart(banda).mark_rect(opacity=0.15, color="orange").encode(y="a:Q", y2="b:Q")
    linha = alt.Chart(pd.DataFrame({"m": [media]})).mark_rule(color="red", strokeDash=[6, 4]).encode(y="m:Q")
    st.altair_chart(faixa + linha + base, use_container_width=True)
    st.caption("🔴 linha = média  ·  🟧 faixa = média ± 1 desvio padrão")
    st.markdown("**🎯 Missões**")
    missao = st.radio("Escolha:", ["Deixe o desvio padrão = 0", "Faça média = mediana (e dp > 0)",
                                   "Deixe o desvio padrão maior que 7"], label_visibility="collapsed")
    ok = {"Deixe o desvio padrão = 0": dp == 0,
          "Faça média = mediana (e dp > 0)": abs(media - med) < 1e-9 and dp > 0,
          "Deixe o desvio padrão maior que 7": dp > 7}[missao]
    (st.success if ok else st.info)("✅ Missão cumprida!" if ok else "Ainda não... continue ajustando!")

# ---------------------------------------------------------------- app
st.title("🎮 StatQuest")
nivel_jogador = S.xp // 60 + 1
c1, c2, c3 = st.columns(3)
c1.metric("🏅 Nível", nivel_jogador)
c2.metric("⚡ XP", S.xp)
c3.metric("⭐ Estrelas", f"{sum(S.estrelas.values())}/{3 * len(NIVEIS)}")
st.progress((S.xp % 60) / 60, text=f"Faltam {60 - S.xp % 60} XP para o nível {nivel_jogador + 1}")

aba1, aba2 = st.tabs(["🗺️ Trilha", "🧪 Laboratório"])
with aba1:
    {"mapa": tela_mapa, "licao": tela_licao, "quiz": tela_quiz}[S.tela]()
with aba2:
    tela_lab()
